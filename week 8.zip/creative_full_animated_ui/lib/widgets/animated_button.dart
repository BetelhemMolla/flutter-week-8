import 'package:flutter/material.dart';

class AnimatedFunkyButton extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  const AnimatedFunkyButton({required this.label, required this.onTap});

  @override
  _AnimatedFunkyButtonState createState() => _AnimatedFunkyButtonState();
}

class _AnimatedFunkyButtonState extends State<AnimatedFunkyButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: Duration(milliseconds: 800))
      ..repeat(reverse: true);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: Tween(begin: 0.98, end: 1.02)
          .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut)),
      child: ElevatedButton(
        onPressed: widget.onTap,
        child: Text(widget.label),
      ),
    );
  }
}
