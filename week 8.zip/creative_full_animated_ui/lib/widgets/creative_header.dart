import 'package:flutter/material.dart';

class CreativeHeader extends StatelessWidget {
  final String title;
  const CreativeHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        CircleAvatar(
          radius: 20,
          backgroundImage: AssetImage('assets/icons/logo.png'),
        ),
        SizedBox(width: 12),
        Text(title, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
      ],
    );
  }
}
