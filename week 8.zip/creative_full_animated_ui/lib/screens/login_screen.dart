import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state/app_state.dart';
import '../widgets/animated_button.dart';
import 'dashboard_screen.dart';
import '../widgets/page_transitions.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  String _name = '';
  late AnimationController _anim;

  @override
  void initState() {
    super.initState();
    _anim = AnimationController(
        vsync: this, duration: Duration(milliseconds: 1000))
      ..repeat(reverse: true);
  }

  @override
  void dispose() {
    _anim.dispose();
    super.dispose();
  }

  void _submit() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      context.read<AppState>().setUserName(_name);
      Navigator.pushReplacement(
          context, SlidePageRoute(page: DashboardScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: TweenAnimationBuilder<double>(
          tween: Tween(begin: 0, end: 1),
          duration: Duration(milliseconds: 900),
          curve: Curves.easeOutBack,
          builder: (context, v, child) {
            return Opacity(
              opacity: v,
              child:
                  Transform.translate(offset: Offset(0, 50 * (1 - v)), child: child),
            );
          },
          child: Card(
            elevation: 10,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Form(
                key: _formKey,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  ScaleTransition(
                    scale: Tween(begin: 0.95, end: 1.05)
                        .animate(CurvedAnimation(parent: _anim, curve: Curves.easeInOut)),
                    child: Text('Welcome!',
                        style:
                            TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  ),
                  SizedBox(height: 12),
                  TextFormField(
                      decoration: InputDecoration(labelText: 'Your name'),
                      onSaved: (v) => _name = v ?? '',
                      validator: (v) =>
                          v == null || v.isEmpty ? 'Enter name' : null),
                  SizedBox(height: 12),
                  TextFormField(
                      decoration: InputDecoration(labelText: 'Email'),
                      validator: (v) =>
                          v == null || v.isEmpty ? 'Enter email' : null),
                  SizedBox(height: 18),
                  AnimatedFunkyButton(label: 'Continue', onTap: _submit),
                  SizedBox(height: 8),
                  TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: Text('Back')),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
