import 'package:flutter/material.dart';
import 'login_screen.dart';
import '../widgets/page_transitions.dart';
import 'dashboard_screen.dart';

class LandingScreen extends StatefulWidget {
  @override
  _LandingScreenState createState() => _LandingScreenState();
}

class _LandingScreenState extends State<LandingScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _bgController;
  late AnimationController _buttonController;

  @override
  void initState() {
    super.initState();
    _bgController =
        AnimationController(vsync: this, duration: Duration(seconds: 6))
          ..repeat();
    _buttonController = AnimationController(
        vsync: this, duration: Duration(milliseconds: 1000))
      ..repeat(reverse: true);
  }

  @override
  void dispose() {
    _bgController.dispose();
    _buttonController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedBuilder(
        animation: _bgController,
        builder: (context, child) {
          return Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color.lerp(Colors.purple, Colors.blue, _bgController.value)!,
                  Color.lerp(Colors.orange, Colors.teal, 1 - _bgController.value)!
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: child,
          );
        },
        child: SafeArea(
          child: Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Hero(
                tag: 'app-logo',
                child: ScaleTransition(
                  scale: Tween(begin: 0.9, end: 1.1)
                      .animate(CurvedAnimation(parent: _buttonController, curve: Curves.easeInOut)),
                  child: CircleAvatar(
                    radius: 60,
                    backgroundImage: AssetImage('assets/icons/logo.png'),
                    backgroundColor: Colors.white24,
                  ),
                ),
              ),
              SizedBox(height: 18),
              Text(
                'Unleash your imagination',
                style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              ),
              SizedBox(height: 8),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 24),
                child: Text(
                  'Design playful, animated UIs and explore styles. This is your creative playground!',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70),
                ),
              ),
              SizedBox(height: 26),
              Row(mainAxisSize: MainAxisSize.min, children: [
                ScaleTransition(
                  scale: Tween(begin: 0.95, end: 1.05)
                      .animate(CurvedAnimation(parent: _buttonController, curve: Curves.easeInOut)),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        shape: StadiumBorder(),
                        padding:
                            EdgeInsets.symmetric(horizontal: 24, vertical: 14)),
                    child: Text('Get Started'),
                    onPressed: () => Navigator.push(
                        context,
                        FadePageRoute(page: LoginScreen())),
                  ),
                ),
                SizedBox(width: 12),
                ScaleTransition(
                  scale: Tween(begin: 0.95, end: 1.05)
                      .animate(CurvedAnimation(parent: _buttonController, curve: Curves.easeInOut)),
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                        shape: StadiumBorder(),
                        padding:
                            EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                        side: BorderSide(color: Colors.white70)),
                    child: Text('Skip', style: TextStyle(color: Colors.white)),
                    onPressed: () => Navigator.push(
                        context,
                        SlidePageRoute(page: DashboardScreen())),
                  ),
                )
              ])
            ]),
          ),
        ),
      ),
    );
  }
}
