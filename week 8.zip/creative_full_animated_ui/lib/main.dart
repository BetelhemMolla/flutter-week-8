import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'state/app_state.dart';
import 'screens/landing_screen.dart';

void main() {
  runApp(ChangeNotifierProvider(
      create: (_) => AppState(), child: CreativeApp()));
}

class CreativeApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Creative Full Animated UI',
      theme: app.darkMode
          ? ThemeData.dark(useMaterial3: true)
          : ThemeData(
              useMaterial3: true,
              colorSchemeSeed: Colors.teal,
            ),
      home: LandingScreen(),
    );
  }
}
