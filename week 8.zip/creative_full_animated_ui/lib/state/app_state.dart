import 'package:flutter/material.dart';

class AppState extends ChangeNotifier {
  String userName = '';
  bool darkMode = false;

  void setUserName(String name) {
    userName = name;
    notifyListeners();
  }

  void toggleDarkMode() {
    darkMode = !darkMode;
    notifyListeners();
  }
}
